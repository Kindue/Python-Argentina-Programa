#Ejercicio 10
#Escriba un programa que permita que el usuario ingrese dos
#valores en las variables a y b y luego empaquete dichos valores en una
#lista. Luego el programa debe imprimir la tupla resultado.


a = input("Ingrese la variable a: ")
b = input("Ingrese la variable b: ")

lista = [a, b]

print("Esta es la lista resultante:", lista)