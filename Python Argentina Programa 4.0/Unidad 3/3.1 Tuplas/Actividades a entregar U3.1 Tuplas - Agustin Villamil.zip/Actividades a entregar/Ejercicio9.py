#Ejercicio 9
#Escriba un programa que permite que el usuario ingrese dos
#valores en las variables a y b y luego empaquete dichos valores en una
#tupla. Finalmente, el programa debe imprimir la tupla resultado.


a = input("Ingrese el primer elemento: ")
b =	input("Ingrese el segundo elemento: ")

tupla = a, b

print("La tupla formada es la siguiente:", tupla)